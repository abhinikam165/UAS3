package com.cg.university.dao;


import java.util.ArrayList;
import java.util.Date;

import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public interface MacDao {


	
	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException;
	
	public ArrayList<Application> filterApplications(
			int marksObtained,String ScheduledProgramId) throws UniversityException;

	public boolean interviewCandidates(int noOfCandidates,
			ArrayList<Application> interviewlist)
			throws UniversityException;

	public boolean setDateOfInterview(Date dateOfInterview)
			throws UniversityException;

	public ArrayList<Application> getAcceptedCandidates(
			String scheduledProgramId) throws UniversityException;

	public  ArrayList<Application> confirmCandidate(String scheduledProgramId)
			throws UniversityException;

	public boolean confirmCandidates(String decision, int applicationId)
			throws UniversityException;

	public boolean rejectCandidates(int noOfCandidates,
			String scheduledProgramId)
			throws UniversityException;
	public boolean validateCredentials(String userName, String password)
			throws UniversityException;
	
}
