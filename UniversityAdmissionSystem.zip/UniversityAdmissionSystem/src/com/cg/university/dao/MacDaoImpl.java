package com.cg.university.dao;

import org.apache.log4j.*;

import java.util.ArrayList;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.university.entities.Application;
import com.cg.university.entities.Participant;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.entities.User;
import com.cg.university.exception.UniversityException;
import com.cg.university.logger.MyLogger;

@Repository
public class MacDaoImpl implements MacDao {

	private static final String Class_Name=MacDaoImpl.class.getName();
	
	Logger logger = MyLogger.getLoggerInstance();
	

	@PersistenceContext
	private EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#getScheduledPrograms()
	 */
	
	
	
	
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Shows list of scheduled program offered by university 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:       Amit Kumar     Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException {
		 

		ArrayList<ProgramsScheduled> list = new ArrayList<ProgramsScheduled>();
		String qStr = "SELECT scprograms FROM ProgramsScheduled scprograms";
		TypedQuery<ProgramsScheduled> query = entityManager.createQuery(qStr,
				ProgramsScheduled.class);
		list = (ArrayList<ProgramsScheduled>) query.getResultList();
		logger.info("SCHEDULED PROGRAMS AVALIABLE IN CLASS:"+Class_Name+"Method name: ArrayList<ProgramsScheduled> getScheduledPrograms(),SCHEDULED PROGRAMS ARE INSERTED");
		if (list.size() == 0) {

			logger.error("ERROR OCCURED IN CLASS:"+Class_Name+"Method name: ArrayList<ProgramsScheduled> getScheduledPrograms(),SCHEDULED PROGRAMS ARE NOT AVALIABLE");
			throw new UniversityException(
					"NO PROGRAMS TO DISPLAY.LIST OF PROGRAMS NOT DECIDED YET BY UNIVERSITY");
		}

		return list;

	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#filterApplications(int, java.lang.String)
	 */
	
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Shows list of students whose marks is greater than cutoff marks and change status to ACCEPTED
	 * Version:     1.0
	 * Modifications:NA
	 * Author:       Shubham Sonar     Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public ArrayList<Application> filterApplications(int marksObtained,
			String ScheduledProgramId) throws UniversityException {

		ArrayList<Application> list = new ArrayList<Application>();
		String qstr = "Select bean from Application bean where MARKS_OBTAINED>:marks AND scheduled_Program_Id=:id AND status=:status";
		TypedQuery<Application> query = entityManager.createQuery(qstr,
				Application.class);
		query.setParameter("marks", marksObtained);
		query.setParameter("id", ScheduledProgramId);
		query.setParameter("status", "PENDING");
		System.out.println(ScheduledProgramId);
		list = (ArrayList<Application>) query.getResultList();
		logger.info("CUTOFLIST IS OCCUERED IN CLASS"+Class_Name+"Method Name: ArrayList<Application> filterApplications(int marksObtained,String ScheduledProgramId),STUDENT FOUND WITH MARKS GREATER THAN " + marksObtained
				+ "PROGRAM ID" + ScheduledProgramId);
		for (Application var : list) {
			var.setStatus("ACCEPTED");
			entityManager.merge(var);
		}

		rejectCandidates(marksObtained, ScheduledProgramId);

		if (list.size() == 0) {

			logger.error("ERROR OCCUERED IN CLASS:"+Class_Name+"Method Name: ArrayList<Application> filterApplications(int marksObtained,String ScheduledProgramId),No student found with marks greater than "
					+ marksObtained + "program id" + ScheduledProgramId);
			throw new UniversityException(
					"NO STUDENT FOUND WITH MARKS GREATER THAN " + marksObtained
							+ " PROGRAM ID " + ScheduledProgramId);
		}

		return list;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#interviewCandidates(int, java.util.ArrayList)
	 */
	
	
	
	
	@Override
	public boolean interviewCandidates(int noOfCandidates,
			ArrayList<Application> interviewlist) throws UniversityException {
		 
		return false;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#setDateOfInterview(java.util.Date)
	 */
	
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Set date of interview for ACCEPTED candidate 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:      Ajay Dhotre      Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public boolean setDateOfInterview(Date dateOfInterview)
			throws UniversityException {
		 
		String qStr = "UPDATE Application SET date_of_interview=:doi where status=:status";
		// TypedQuery<Application> query = entityManager.createQuery(qStr,
		// Application.class);
		Query query = entityManager.createQuery(qStr);
		query.setParameter("doi", dateOfInterview);
		query.setParameter("status", "ACCEPTED");
		int row = query.executeUpdate();

		if (row != 0) {
			logger.info("INTERVIEW DATE IS SET IN CLASS:"+Class_Name+"METHOD NAME:setDateOfInterview(Date dateOfInterview),INTERVIEW DATE IS SUCCESFULY SET WHOSE STATUS IS ACCEPTED");
			return true;
		} else {
			logger.error("ERROR OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:setDateOfInterview(Date dateOfInterview),NO STUDENT FOUND WITH STATUS ACCEPTED");
			throw new UniversityException("No rows Inserted");
		}

	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#getAcceptedCandidates(java.lang.String)
	 */
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Shows list of candidates whose status is PENDING
	 * Version:     1.0
	 * Modifications:NA
	 * Author:       Shruthi Ramesh     Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@Override
	public ArrayList<Application> getAcceptedCandidates(
			String scheduledProgramId) throws UniversityException {
		ArrayList<Application> list = new ArrayList<Application>();
		String qStr = "SELECT application FROM Application application where SCHEDULED_PROGRAM_ID=:id AND status=:status";

		TypedQuery<Application> query = entityManager.createQuery(qStr,
				Application.class);
		query.setParameter("id", scheduledProgramId);
		query.setParameter("status", "PENDING");
		list = (ArrayList<Application>) query.getResultList();
		logger.info("INFORMATION ABOUT CANDIDATES ARE IN CLASS:"+Class_Name+"METHOD NAME:ArrayList<Application> getAcceptedCandidates(String scheduledProgramId) ,GET INFORMATION ABOUT CANDIDATE  STATUS IS PENDING ");
		if (list.size() == 0) {

			logger.error("ERROR OCCURRED IN CLASS"+Class_Name+"Method Name:ArrayList<Application> getAcceptedCandidates(String scheduledProgramId)NO CANDIDATE FOUND WITH SCHEDULED PROGRAM ID :"
					+ scheduledProgramId);
			throw new UniversityException("NO CANDIDATE FOUND WITH PROGRAM ID"
					+ scheduledProgramId);
		}

		return list;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#confirmCandidate(java.lang.String)
	 */
	
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Shows list of confirm candidates whose status is PENDING
	 * Version:     1.0
	 * Modifications:NA
	 * Author:     Ajay Dhotre       Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public ArrayList<Application> confirmCandidate(String scheduledProgramId)
			throws UniversityException {
		 
		ArrayList<Application> list = new ArrayList<Application>();
		String qStr = "SELECT application FROM Application application where SCHEDULED_PROGRAM_ID=:id AND status=:status";

		TypedQuery<Application> query = entityManager.createQuery(qStr,
				Application.class);
		query.setParameter("id", scheduledProgramId);
		query.setParameter("status", "ACCEPTED");
		list = (ArrayList<Application>) query.getResultList();
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:confirmCandidate(String scheduledProgramId),GET DETAIL ABOUT CANDIDATE STATUS IS ACCEPTED");

		if (list.size() == 0) {
			logger.error("ERROR OCCUERED IN CLASS"+Class_Name+"METHOD NAME:ArrayList<Application> confirmCandidate(String scheduledProgramId),NO STUDENT FOUND WITH STATUS ACCEPTED ");
			throw new UniversityException(
					"ADMISSION PROCESS COMPLETED. NO STUDENTS TO DISPLAY");
		}

		return list;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#confirmCandidates(java.lang.String, int)
	 */
	
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        Shows details about confirm candidate for specific application id 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:      Shruthi Ramesh      Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public boolean confirmCandidates(String decision, int applicationId)
			throws UniversityException {
		 

		Application bean = entityManager.find(Application.class, applicationId);
		bean.setStatus(decision);
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME: boolean confirmCandidates(String decision, int applicationId),GET INFORMATION ABOUT APPLICANTS WHOS APPLICATION ID IS:"+applicationId);
		entityManager.merge(bean);
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME: boolean confirmCandidates(String decision, int applicationId),UPDATE THE INFORMATION OF APPLICANTS WHOS APPLICATION ID IS:"+applicationId);
		if(decision.equals("CONFIRMED"))
		{
			Participant participant=new Participant();
			participant.setEmailId(bean.getEmailId());
			participant.setProgramsScheduled(bean.getProgramsScheduled());
			participant.setApplicationId(applicationId);
			entityManager.persist(participant);
			entityManager.flush();
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#rejectCandidates(int, java.lang.String)
	 */
	@Override
	public boolean rejectCandidates(int marksObtained, String ScheduledProgramId)
			throws UniversityException {
		 
		ArrayList<Application> list = new ArrayList<Application>();
		String qstr = "Select bean from Application bean where MARKS_OBTAINED<=:marks AND scheduled_Program_Id=:id";
		TypedQuery<Application> query = entityManager.createQuery(qstr,
				Application.class);
		query.setParameter("marks", marksObtained);
		query.setParameter("id", ScheduledProgramId);
		System.out.println(ScheduledProgramId);
		list = (ArrayList<Application>) query.getResultList();
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:rejectCandidates(int marksObtained, String ScheduledProgramId),GET LIST OF CANDIDATE WHOSE MARKS LESS THAN CUTOFF LIST");
		for (Application var : list) {
			var.setStatus("REJECTED");
			entityManager.merge(var);
		}

		if (list.size() == 0) {
			logger.error("ERROR OCCURRED IN CLASS"+Class_Name+"METHOD NAME:rejectCandidates(int marksObtained, String ScheduledProgramId),NO STUDENT FOUND WITH MARKS IS LESS THAN CUTOFF LIST ");
			throw new UniversityException("Records Are not available");
		}

		return true;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.MacDao#validateCredentials(java.lang.String, java.lang.String)
	 */
	/************************************************************************************
	 * File:    MacDaoImpl    
	 * Package:     com.cg.university.dao
	 * Desc:        validate the credentials for  MAC login 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:      Ruchika Mondhe      Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public boolean validateCredentials(String userName, String password)
			throws UniversityException {

		User obj = entityManager.find(User.class, userName);
		if (obj == null) {

			logger.error("ERROR OCCURRED IN CLASS"+Class_Name+"Method Name:boolean validateCredentials(String userName, String password),WRONG CREDENTIALS");
			throw new UniversityException("PLEASE ENTER VALID VALUES");
		}

		else if (obj.getLoginId().equals(userName)
				&& obj.getPassword().equals(password)) {
			logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:boolean validateCredentials(String userName, String password),CREDENTIALS ARE SUCCESSFULY VALIDATED");
			return true;
		} else {
			logger.error("ERROR OCCURRED IN CLASS"+Class_Name+"METHOD NAME:boolean validateCredentials(String userName, String password),WRONG CREDENTIALS");
			throw new UniversityException("PLEASE ENTER VALID VALUES");
		}

	}
}