package com.cg.university.controller;

import java.sql.Date;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.entities.User;
import com.cg.university.exception.UniversityException;
import com.cg.university.service.MacServices;
import com.cg.university.service.StudentServices;


@Controller
public class UniversityController {

	boolean flag = false;

	@Autowired
	Application application;

	@Autowired
	User user;

	@Autowired
	ProgramsOffered programsOffered;

	@Autowired
	ProgramsScheduled programsScheduled;

	@Autowired
	MacServices macService;

	@Autowired
	StudentServices studentService;

	String sId;


	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to home
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/

	@RequestMapping("/Home")
	public String redirect() {
		return "Home";
	}
	

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to mac home
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/MacHome")
	public String gotoMacHome(Model model) {
		
		ArrayList<ProgramsScheduled> scheduledList = new ArrayList<ProgramsScheduled>();

		try {
			scheduledList = macService.getScheduledPrograms();
			model.addAttribute("scheduledList", scheduledList);
			return "MacHome";
		} catch (Exception e) {
			 
			model.addAttribute("message", e.getMessage());
			return "MacHome";
		}

		
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to logout page
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/logout")
	public String logOutMac() {
		return "Logout";
	}
	
	

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to login page
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/login")
	public String validateUser(Model model) {
		model.addAttribute("user", user);
		return "Login";
	}


	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of programs offered by the university
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/programs")
	public String showPrograms(User user, Model model)
			throws UniversityException {

		ArrayList<ProgramsOffered> programsList = new ArrayList<ProgramsOffered>();

		try {
			programsList = studentService.getAllPrograms();
			model.addAttribute("programsList", programsList);
			return "ProgramsOffered";
		} catch (UniversityException e) {
			 
			model.addAttribute("message", e.getMessage());
			return "Home";
		}

	}


	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of programs scheduled by the university
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/scprograms")
	public String showScheduledPrograms(User user, Model model)
			throws UniversityException {
		ArrayList<ProgramsScheduled> scheduledList = new ArrayList<ProgramsScheduled>();

		try {
			scheduledList = studentService.getScheduledPrograms();
			model.addAttribute("scheduledList", scheduledList);
			return "ScheduledPrograms";
		} catch (Exception e) {
			 
			model.addAttribute("message", e.getMessage());
			return "Home";
		}
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Check credentials 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/checkCredentials")
	public String checkCredentials(User user, Model model)
			throws UniversityException {
		try {
			flag = macService.validateCredentials(user.getLoginId(),
					user.getPassword());
		} catch (UniversityException e) {
			model.addAttribute("message", e.getMessage());
			return "Login";
		}

		if (flag) {
			ArrayList<ProgramsScheduled> scheduledList = new ArrayList<ProgramsScheduled>();

			try {
				scheduledList = macService.getScheduledPrograms();
				model.addAttribute("scheduledList", scheduledList);
				return "MacHome";
			} catch (Exception e) {
				 
				model.addAttribute("message", e.getMessage());
				return "Login";
			}

		} else {
			return "Login";
		}

	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to registration page
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/apply")
	public String register(@RequestParam("id") String id, User user, Model model) {

		model.addAttribute("id", id);
		model.addAttribute("application", application);

		return "Registration";
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Accept details from student for enrollment 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/acceptDetails")
	public String newCandidate(@RequestParam("id") String id,
			Application application, Model model) {
		try {


			programsScheduled.setScheduledProgramId(id);
			application.setProgramsScheduled(programsScheduled);

			studentService.insertApplication(application);
			System.out.println(application);
		} catch (UniversityException e) {
			 
			e.printStackTrace();
		}

		model.addAttribute("application", application);

		return "Success";
	}

	
	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of students for a particular program
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/viewStudent")
	public String viewStudents(@RequestParam("id") String id, User user,
			Model model) throws UniversityException {

		ArrayList<Application> studentList;
		studentList = new ArrayList<Application>();
		System.out.println(id);
		try {
			studentList = macService.getAcceptedCandidates(id);
		} catch (UniversityException e) {
			 
			model.addAttribute("message", e.getMessage());
			return "CutOffList";

		}
		model.addAttribute("studentList", studentList);
		model.addAttribute("application", application);
		model.addAttribute("id", id);
		return "CutOffList";
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Show list of confirmed candidates
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/confirm")
	public String confirm(@RequestParam("id") int id, User user, Model model)
			throws UniversityException {

		flag = macService.confirmCandidates("CONFIRMED", id);
		ArrayList<Application> studentList;
		studentList = new ArrayList<Application>();
		try {
			studentList = macService.confirmCandidate(sId);
		} catch (Exception e) {
			 
			model.addAttribute("message", e.getMessage());
		}

		model.addAttribute("confirmList", studentList);
		model.addAttribute("application", application);
		model.addAttribute("id", sId);
		return "Confirm";

	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of rejected candidates
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/reject")
	public String reject(@RequestParam("id") int id, User user, Model model) {
		try {
			flag = macService.confirmCandidates("REJECTED", id);
			ArrayList<Application> studentList;
			studentList = new ArrayList<Application>();
			System.out.println(id);

			studentList = macService.confirmCandidate(sId);
			model.addAttribute("confirmList", studentList);
			model.addAttribute("application", application);
			model.addAttribute("id", sId);
		} catch (UniversityException e) {
			model.addAttribute("message", e.getMessage());
			return "Confirm";
		}

		return "Confirm";

	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of accepted students
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/viewAcceptedStudent")
	public String viewApplicantStudents(@RequestParam("id") String id,
			User user, Model model) {

		ArrayList<Application> studentList;
		studentList = new ArrayList<Application>();
		System.out.println(id);
		sId = id;
		try {
			studentList = macService.confirmCandidate(id);
			model.addAttribute("confirmList", studentList);
			model.addAttribute("application", application);
			model.addAttribute("id", id);

		} catch (UniversityException e) {
			model.addAttribute("message", e.getMessage());
			return "Confirm";
		}
		return "Confirm";
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Shows list of students and apply the cut off marks 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/cutoflist")
	public String cutOfList(@RequestParam("marks") int marks,
			@RequestParam("id") String id, Model model) {
		ArrayList<Application> list = new ArrayList<Application>();

		// ArrayList<Application> studentList = new ArrayList<Application>();

		try {
			System.out.println(marks);

			list = macService.filterApplications(marks, id);
			System.out.println(list);
			model.addAttribute("marks", marks);
			model.addAttribute("cutOfflist", list);
		} catch (UniversityException e) {
			model.addAttribute("message", e.getMessage());
		}
		return "Interview";
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Date of interview is set 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/acceptDOI")
	public String cutOfList(@RequestParam("doi") String doi,
			Application application, Model model) {
		try {
			macService.setDateOfInterview(Date.valueOf(doi));

		} catch (Exception e) {
			 
			model.addAttribute("message", e.getMessage());
			return "Interview";
		}

		return "InterviewSuccess";
	}

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Redirects to status page
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/status")
	public String gotoStatusPage(Model model) {
		model.addAttribute("application", application);
		return "Status";
	}
	

	/************************************************************************************
	 * File:   UniversityController     
	 * Package:     com.cg.university.controller
	 * Desc:        Show details of student fetched by application id
	 * Version:     1.0
	 * Modifications:NA
	 * Author:            Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	@RequestMapping("/viewStatus")
	public String getStatus(@ModelAttribute("application")Application application, Model model) {

		try {
			Application statusDetails;

			statusDetails = studentService.getApplicationStatus(application.getApplicationId());
			if (statusDetails.getStatus().equals("PENDING")) {
				model.addAttribute("message",
						"Your status Is pending Please wait for the confirmation from Members of "
								+ "Admission Commitee");
			} else if (statusDetails.getStatus().equals("ACCEPTED")) {
				
			}
			System.out.println(statusDetails);
			model.addAttribute("application", statusDetails);
			model.addAttribute("statusDetails", statusDetails);
		} catch (UniversityException e) {
			model.addAttribute("message", e.getMessage());
			return "Status";
		}
		return "Status";

	}

}
