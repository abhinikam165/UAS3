package com.cg.university.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The persistent class for the PROGRAMS_OFFERED database table.
 * 
 */
@Component
@Entity
@Table(name="PROGRAMS_OFFERED")
@NamedQuery(name="ProgramsOffered.findAll", query="SELECT p FROM ProgramsOffered p")
public class ProgramsOffered implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PROGRAM_ID", unique=true, nullable=false, length=5)
	private String programId;

	@Column(name="APPLICANT_ELIGIBILITY", length=40)
	private String applicantEligibility;

	@Column(name="DEGREE_CERTIFICATE_OFFERED", length=10)
	private String degreeCertificateOffered;

	@Column(length=20)
	private String description;

	private int duration;

	@Column(name="PROGRAM_NAME", updatable=false, length=20)
	private String programName;

	//bi-directional one-to-one association to ProgramsScheduled
	@OneToOne(mappedBy="programsOffered1")
	private ProgramsScheduled programsScheduled;

	//bi-directional many-to-one association to ProgramsScheduled
	@OneToMany(mappedBy="programsOffered2")
	private List<ProgramsScheduled> programsScheduleds;

	public ProgramsOffered() {
	}

	public String getProgramId() {
		return this.programId;
	}

	public void setProgramId(String programId) {
		this.programId = programId;
	}

	public String getApplicantEligibility() {
		return this.applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public String getDegreeCertificateOffered() {
		return this.degreeCertificateOffered;
	}

	public void setDegreeCertificateOffered(String degreeCertificateOffered) {
		this.degreeCertificateOffered = degreeCertificateOffered;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getProgramName() {
		return this.programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public ProgramsScheduled getProgramsScheduled() {
		return this.programsScheduled;
	}

	public void setProgramsScheduled(ProgramsScheduled programsScheduled) {
		this.programsScheduled = programsScheduled;
	}

	public List<ProgramsScheduled> getProgramsScheduleds() {
		return this.programsScheduleds;
	}

	public void setProgramsScheduleds(List<ProgramsScheduled> programsScheduleds) {
		this.programsScheduleds = programsScheduleds;
	}

	public ProgramsScheduled addProgramsScheduled(ProgramsScheduled programsScheduled) {
		getProgramsScheduleds().add(programsScheduled);
		programsScheduled.setProgramsOffered2(this);

		return programsScheduled;
	}

	public ProgramsScheduled removeProgramsScheduled(ProgramsScheduled programsScheduled) {
		getProgramsScheduleds().remove(programsScheduled);
		programsScheduled.setProgramsOffered2(null);

		return programsScheduled;
	}

}