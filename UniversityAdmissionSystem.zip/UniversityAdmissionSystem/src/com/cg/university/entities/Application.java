package com.cg.university.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.Date;


/**
 * The persistent class for the APPLICATION database table.
 * 
 */
@Component
@Entity
@Table(name="APPLICATION")
@NamedQuery(name="Application.findAll", query="SELECT a FROM Application a")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="APPLICATION_APPLICATIONID_GENERATOR", sequenceName="APP_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="APPLICATION_APPLICATIONID_GENERATOR")
	@Column(name="APPLICATION_ID", insertable=false, updatable=false, unique=true, nullable=false)
	private int applicationId;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_BIRTH")
	private Date dateOfBirth;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_INTERVIEW")
	private Date dateOfInterview;

	@Column(name="EMAIL_ID", length=20)
	private String emailId;

	@Column(name="FULL_NAME", length=20)
	private String fullName;

	@Column(length=20)
	private String goals;

	@Column(name="HIGHEST_QUALIFICATION", length=10)
	private String highestQualification;

	@Column(name="MARKS_OBTAINED")
	private int marksObtained;

	@Column(length=10)
	private String status;

	//bi-directional many-to-one association to ProgramsScheduled
	@ManyToOne
	@JoinColumn(name="SCHEDULED_PROGRAM_ID")
	private ProgramsScheduled programsScheduled;

	public Application() {
	}

	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfInterview() {
		return this.dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFullName() {
		return this.fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGoals() {
		return this.goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getHighestQualification() {
		return this.highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public int getMarksObtained() {
		return this.marksObtained;
	}

	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ProgramsScheduled getProgramsScheduled() {
		return this.programsScheduled;
	}

	public void setProgramsScheduled(ProgramsScheduled programsScheduled) {
		this.programsScheduled = programsScheduled;
	}

	@Override
	public String toString() {
		return "Application [applicationId=" + applicationId + ", dateOfBirth="
				+ dateOfBirth + ", dateOfInterview=" + dateOfInterview
				+ ", emailId=" + emailId + ", fullName=" + fullName
				+ ", goals=" + goals + ", highestQualification="
				+ highestQualification + ", marksObtained=" + marksObtained
				+ ", status=" + status + ", programsScheduled="
				+ programsScheduled + "]";
	}

	

	

	
	
}