package com.cg.university.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PROGRAMS_SCHEDULED database table.
 * 
 */
@Component
@Entity
@Table(name="PROGRAMS_SCHEDULED")
@NamedQuery(name="ProgramsScheduled.findAll", query="SELECT p FROM ProgramsScheduled p")
public class ProgramsScheduled implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PROGRAMS_SCHEDULED_SCHEDULEDPROGRAMID_GENERATOR", sequenceName="APP_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROGRAMS_SCHEDULED_SCHEDULEDPROGRAMID_GENERATOR")
	@Column(name="SCHEDULED_PROGRAM_ID", updatable=false, unique=true, nullable=false, length=5)
	private String scheduledProgramId;

	@Temporal(TemporalType.DATE)
	@Column(name="END_DATE")
	private Date endDate;

	@Column(length=10)
	private String location;

	@Column(name="PROGRAM_NAME", length=5)
	private String programName;

	@Column(name="SESSIONS_PER_WEEK")
	private int sessionsPerWeek;

	@Temporal(TemporalType.DATE)
	@Column(name="START_DATE")
	private Date startDate;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="programsScheduled")
	private List<Application> applications;

	//bi-directional many-to-one association to Participant
	@OneToMany(mappedBy="programsScheduled")
	private List<Participant> participants;

	//bi-directional one-to-one association to ProgramsOffered
	@OneToOne
	@JoinColumn(name="SCHEDULED_PROGRAM_ID", nullable=false, insertable=false, updatable=false)
	private ProgramsOffered programsOffered1;

	//bi-directional many-to-one association to ProgramsOffered
	@ManyToOne
	@JoinColumn(name="PROGRAM_ID")
	private ProgramsOffered programsOffered2;

	public ProgramsScheduled() {
	}

	public String getScheduledProgramId() {
		return this.scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getProgramName() {
		return this.programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public int getSessionsPerWeek() {
		return this.sessionsPerWeek;
	}

	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public List<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setProgramsScheduled(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setProgramsScheduled(null);

		return application;
	}

	public List<Participant> getParticipants() {
		return this.participants;
	}

	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}

	public Participant addParticipant(Participant participant) {
		getParticipants().add(participant);
		participant.setProgramsScheduled(this);

		return participant;
	}

	public Participant removeParticipant(Participant participant) {
		getParticipants().remove(participant);
		participant.setProgramsScheduled(null);

		return participant;
	}

	public ProgramsOffered getProgramsOffered1() {
		return this.programsOffered1;
	}

	public void setProgramsOffered1(ProgramsOffered programsOffered1) {
		this.programsOffered1 = programsOffered1;
	}

	public ProgramsOffered getProgramsOffered2() {
		return this.programsOffered2;
	}

	public void setProgramsOffered2(ProgramsOffered programsOffered2) {
		this.programsOffered2 = programsOffered2;
	}
	
	

}