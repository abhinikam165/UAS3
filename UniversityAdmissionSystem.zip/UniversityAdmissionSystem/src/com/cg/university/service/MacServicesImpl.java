package com.cg.university.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.university.dao.MacDao;
import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;


@Transactional
@Service
public class MacServicesImpl implements MacServices {

	
	
	
	
	@Autowired
	MacDao dao;
	
	
	public void setDao(MacDao dao)
	{
		this.dao=dao;
	}
	
	
	@Override
	public boolean validateCredentials(String userName, String password) throws UniversityException {
		// TODO Auto-generated method stub
		/*if(userName.equals("mac") && password.equals("1234"))
		{
			return true;
		}
		else
		return false;*/
		return dao.validateCredentials(userName, password);
	}

	@Override
	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getScheduledPrograms();
	}

	@Override
	public ArrayList<Application> filterApplications(int marksObtained,String ScheduledProgramId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.filterApplications(marksObtained, ScheduledProgramId);
	}

	@Override
	public boolean validateRole(String role) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateLoginId(String loginId) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean interviewCandidates(int noOfCandidates,
			ArrayList<Application> interviewlist) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean setDateOfInterview(Date dateOfInterview)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.setDateOfInterview(dateOfInterview);
	}

	@Override
	public ArrayList<Application> getAcceptedCandidates(
			String scheduledProgramId) throws UniversityException {
		
		return dao.getAcceptedCandidates(scheduledProgramId);
	}

	@Override
	public  ArrayList<Application> confirmCandidate(String scheduledProgramId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.confirmCandidate(scheduledProgramId);
	}

	@Override
	public boolean confirmCandidates(String decision, int applicationId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.confirmCandidates(decision, applicationId);
	}

	/*@Override
	public boolean rejectCandidates(int noOfCandidates,
			int noOfCandidates,
			String scheduledProgramId) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}*/

}
