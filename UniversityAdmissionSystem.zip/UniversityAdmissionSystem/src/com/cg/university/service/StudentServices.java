package com.cg.university.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public interface StudentServices {

	public void insertApplication(Application bean)
			throws UniversityException;

	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException;

	public ArrayList<ProgramsOffered> getAllPrograms()
			throws UniversityException;

	public Application getApplicationStatus(int applicationId)
			throws UniversityException;

	public LocalDate getInterviewDate(int applicationId)
			throws UniversityException;

	public boolean validateName(String studentName) throws UniversityException;

	public boolean validateId(int applicationId) throws UniversityException;
	
	public boolean validateDob(LocalDate dateOfBirth)
			throws UniversityException;

	public boolean validateQualification(String qualification)
			throws UniversityException;

	public boolean validateMarks(int marks) throws UniversityException;

	public boolean validateEmail(String emailId) throws UniversityException;

	public boolean validateGoals(String goals) throws UniversityException;

	public boolean validateScheduledProgramId(String scheduledProgramId)
			throws UniversityException;
	
}
